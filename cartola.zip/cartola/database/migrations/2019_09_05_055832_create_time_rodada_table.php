<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTimeRodadaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('time_rodada', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('usuario_id')->unsigned();
            $table->bigInteger('rodada_id')->unsigned();
            $table->bigInteger('jogador_id')->unsigned();
            $table->foreign('usuario_id')->
            references('id')->
            on('users');
            $table->foreign('rodada_id')->
            references('id')->
            on('rodada');
            $table->foreign('jogador_id')->
            references('id')->
            on('jogador');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('time_rodada');
    }
}
