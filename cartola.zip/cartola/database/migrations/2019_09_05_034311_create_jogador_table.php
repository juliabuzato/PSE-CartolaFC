<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateJogadorTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('jogador', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('nome',40);
            $table->decimal('valor',10,2);
            $table->string('url_img',100);
            //UNSIGNED – Todos os tipos inteiros no MySQL podem ter o atributo opcional UNSIGNED. Quando queremos bloquear inserção de valores negativos em uma coluna utilizamos o parâmetro UNSIGNED. Chave estrangeira precisa ser unsigned.

            $table->bigInteger('time_id')->unsigned(); 
            $table->foreign('time_id')->
            references('id')->
            on('time');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('jogador');
    }
}
