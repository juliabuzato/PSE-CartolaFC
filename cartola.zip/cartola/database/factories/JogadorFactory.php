<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Jogador;
use Faker\Generator as Faker;

$factory->define(Jogador::class, function (Faker $faker) {
	static $sequencial = 1;
    return [
        'nome' => $faker->firstName,
        'url_img' => "img/jogadores/".$sequencial++.".png",
        'valor' => $faker->randomFloat($nbMaxDecimals = 2, $min = 10, $max = 20),
        'time_id' => App\Time::all(['id'])->random()
    ];
});
