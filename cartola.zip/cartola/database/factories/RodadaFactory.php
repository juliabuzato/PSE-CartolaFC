<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Rodada;
use Faker\Generator as Faker;

$factory->define(Rodada::class, function (Faker $faker) {
    return [
       'nome'=>"rodada X"
    ];
});
