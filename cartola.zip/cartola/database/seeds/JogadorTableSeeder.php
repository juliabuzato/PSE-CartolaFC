<?php

use Illuminate\Database\Seeder;

class JogadorTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(App\Jogador::class,18)->create();
    }
}
