<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();

Route::middleware(['auth'])->group(function () {
	Route::get('/', 'JogadorController@index');
	Route::get('/time', 'JogadorController@index');
	Route::get('/home', 'JogadorController@index');
	Route::get('/meuTime', 'JogadorController@meuTime');
	Route::get('/{id}', 'JogadorController@associar');
	Route::get('/remover/{id}', 'JogadorController@remover');
	//Route::get('/home', 'HomeController@index')->name('home');
});
