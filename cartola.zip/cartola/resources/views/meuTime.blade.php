@extends('template.index')
@section('Titulo','CARTOLA FC')
@section('corpo')
  <!-- Portfolio Section -->
  <section class="page-section portfolio" id="corpo">
    <div class="container">

      <!-- Portfolio Section Heading -->
      <h2 class="page-section-heading text-center text-uppercase text-secondary mb-0">Meus Jogadores</h2>

      <!-- Icon Divider -->
      <div class="divider-custom">
        <div class="divider-custom-line"></div>
        <div class="divider-custom-icon">
          <i class="fas fa-star"></i>
        </div>
        <div class="divider-custom-line"></div>
      </div>

      <!-- Jogadores -->
      <div class="row">
        @foreach ($jogadores as $j)
        <div class="col-md-6 col-lg-4">            
          <a href="remover/{{$j->id}}">
            <div class="portfolio-item mx-auto">
            <div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100">
              <div class="portfolio-item-caption-content text-center text-white">
                <i class="fas fa-minus">REMOVER</i>
              </div>
            </div>
            <div class="row">
              <div class="column">
                <img class="img-fluid" src="{{$j->url_img}}" alt=""> 
              </div>
              <div class="column textoRodrigo">
                 <p></p>
                 <p>Nome: {{$j->nome}} </p>
                 <p>Time: {{$j->time_nome}}</p>
                 <p>Valor: {{$j->valor}}</p>
                 <p> Média Pts: ?? </p>                 
              </div>
            </div>
          </div>
          </a>
        </div>
        @endforeach
      <!-- /.row -->

    </div>
  </section>
@endsection('corpo')