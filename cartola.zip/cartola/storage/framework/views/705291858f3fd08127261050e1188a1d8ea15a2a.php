<?php $__env->startSection('Titulo','CARTOLA FC'); ?>
<?php $__env->startSection('corpo'); ?>
  <!-- Portfolio Section -->
  <section class="page-section portfolio" id="corpo">
    <div class="container">

      <!-- Portfolio Section Heading -->
      <h2 class="page-section-heading text-center text-uppercase text-secondary mb-0">Jogadores</h2>

      <!-- Icon Divider -->
      <div class="divider-custom">
        <div class="divider-custom-line"></div>
        <div class="divider-custom-icon">
          <i class="fas fa-star"></i>
        </div>
        <div class="divider-custom-line"></div>
      </div>

      <!-- Jogadores -->
      <div class="row">
        <?php $__currentLoopData = $jogadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6 col-lg-4">            
          <a href="<?php echo e($j->id); ?>">
            <div class="portfolio-item mx-auto">
            <div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100">
              <div class="portfolio-item-caption-content text-center text-white">
                <i class="fas fa-plus fa-3x">Add</i>
              </div>
            </div>
            <div class="row">
              <div class="column">
                <img class="img-fluid" src="<?php echo e($j->url_img); ?>" alt=""> 
              </div>
              <div class="column textoRodrigo">
                 <p></p>
                 <p>Nome: <?php echo e($j->nome); ?> </p>
                 <p>Time: <?php echo e($j->time_nome); ?></p>
                 <p>Valor: <?php echo e($j->valor); ?></p>
                 <p> Média Pts: ?? </p>                 
              </div>
            </div>
          </div>
          </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <!-- /.row -->

    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cartola\resources\views/welcome.blade.php ENDPATH**/ ?>