<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Jogador;
use Illuminate\Support\Facades\DB;

class JogadorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $jogadores = DB::table('jogador')
            ->join('time', 'time.id', '=', 'jogador.time_id')            
            ->select('jogador.*', 'time.nome as time_nome')
            ->get();      
        return view('welcome',compact('jogadores'));

    }

    public function associar($parametro_id){
        $id_usuario =  auth()->user()->id;
        $id_jogador =  $parametro_id;
        $id_rodada_atual = DB::table('rodada')            
            ->max('id');                  
        $quantidade_jogadores = DB::table('time_rodada')
         ->where([
                        ['rodada_id','=',$id_rodada_atual],
                        ['usuario_id','=',$id_usuario],
                        ['jogador_id','=',$id_jogador]
                    ])
            ->count();
         $quantidade_jogadores_total = DB::table('time_rodada')
         ->where([
                        ['rodada_id','=',$id_rodada_atual],
                        ['usuario_id','=',$id_usuario],
                    ])
            ->count();
        if ($quantidade_jogadores < 1 && $quantidade_jogadores_total < 11){

                DB::table('time_rodada')->insert(
                    array('jogador_id' => $id_jogador, 
                        'rodada_id' => $id_rodada_atual,
                        'usuario_id' => $id_usuario)
                );
            } 
           

       return redirect('/meuTime');
    }


    public function meuTime(){
        $id_rodada_atual = DB::table('rodada')            
            ->max('id'); 
        $id_usuario =  auth()->user()->id;  
        $jogadores = DB::table('time_rodada')
            ->join('jogador', 'jogador.id', '=', 'time_rodada.jogador_id')
            ->join('time', 'time.id', '=', 'jogador.time_id')              
            ->select('jogador.*', 'time.nome as time_nome')
            ->where([
                        ['rodada_id','=',$id_rodada_atual],
                        ['usuario_id','=',$id_usuario]
                    ])

            ->get();      
        return view('meuTime',compact('jogadores'));
    }

    public function remover($id_jogador){
        $id_rodada_atual = DB::table('rodada')            
            ->max('id'); 
        $id_usuario =  auth()->user()->id;  
        DB::table('time_rodada')
            ->where([
                        ['rodada_id','=',$id_rodada_atual],
                        ['usuario_id','=',$id_usuario],
                        ['jogador_id','=',$id_jogador]
                    ])
            ->delete();
            return redirect('/meuTime');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
