<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TimeRodada extends Model
{
    protected $table = 'time_rodada';
    protected $fillable = ['usuario_id','rodada_id','jogador_id'];
}

