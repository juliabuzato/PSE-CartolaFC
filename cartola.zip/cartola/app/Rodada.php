<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Rodada extends Model
{
    protected $table = 'rodada';
    protected $fillable = ['nome'];
}

