<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Jogador extends Model
{
	protected $table = 'jogador';
    protected $fillable = ['nome','valor','url_img','time_id'];
}
